# pyre-ignore
from data_generator.main import main

if __name__ == "__main__":
    main()
