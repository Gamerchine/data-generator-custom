# Changelog

### v1.0.1

- fixed -h for data subparser not functioning due to argparser module not handling % in strings very well
- clarification in readme.md added

### v1.0.0

- production version release
